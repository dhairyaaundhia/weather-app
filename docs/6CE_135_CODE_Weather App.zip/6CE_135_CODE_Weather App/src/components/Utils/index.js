import Img from './Img'

//  import Map from './Map'
import SearchBar from './SearchBar'
import SearchBar2 from './SearchBar2'
import TempsData from './TempsData'
import WelcomeMessage from './WelcomeMessage'
import WindHumData from './WindHumData'
export { Img, SearchBar , SearchBar2 , TempsData, WindHumData, WelcomeMessage }
